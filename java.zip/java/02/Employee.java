/**
 * Employee
 */
public class Employee {

    public String name;
    private double salary;
    public Employee(String name){
        this.name = name;
    }

    public void setSalary(double salary){
        this.salary = salary;
    }

    public void printEmp(){
        System.out.println("name : " + name);
        System.out.println("salary : " + salary);
    }

    public static void main(String[] args){
        Employee emp = new Employee("RS");
        emp.setSalary(1000);
        emp.printEmp();
    }
}