/**
 * Test5
 */
import java.util.Arrays;
public class Test5 {

    public static void main(String[] args) {
        // int[] arr = new int[4];
        // Arrays.fill(arr, 2);
        // for (int i = 0; i < arr.length; i++) {
        //     System.out.println(arr[i]);
        // }

        int[] arr1 = {12,34,56,45};
        Arrays.sort(arr1);
        for (int var : arr1) {
            System.out.println(var);
        }

        int[] arr2 = {12,34,56,45};
        int[] arr3 = arr1;
        System.out.println(Arrays.equals(arr1,arr2));
        System.out.println(Arrays.equals(arr1, arr3));
        System.out.println(Arrays.binarySearch(arr1, 34));
    }
}