/**
 * Test9
 */
public class Test9 {

    public static void main(String[] args) {
        Character ch = new Character('a');
        System.out.println(ch);
    }
}