/**
 * Test10
 */
public class Test10 {

    public static void main(String[] args) {
        String str1 = new String();
        System.out.println(str1);
        byte[] b = {1,3,4,5};
        String str2 = new String(b);
        System.out.println(str2);
        char[] chs = {'a','b','c'};
        String str4 = new String(chs);
        System.out.println(str4);
        String str5 = new String("�й�");
        System.out.println(str5);
    }
}