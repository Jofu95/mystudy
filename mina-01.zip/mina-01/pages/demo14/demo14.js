// pages/demo14/demo14.js
Page({
  data:{
    gender:""
  },
  handleChange(e){
    let gender = e.detail.value;
    this.setData({
      gender
    })
  }
})