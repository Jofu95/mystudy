/**
 * SerializeDemo
 */
import java.io.*;
public class SerializeDemo {

    public static void main(String[] args) {
        Employee e = new Employee();
        e.name = "Reyan Ali";
        e.address = "Phokka Kuan, Ambehta Peer";
        e.SSN = 111222333;
        e.number = 101;

        File f = new File("employee.ser");
        try {
            if(!f.exists()){
                f.createNewFile();
            }
            FileOutputStream fos = new FileOutputStream("employee.ser");
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(e);
            oos.close();
            fos.close();
            System.out.println("Serialized data is saved in employee.ser");

        } catch (IOException i) {
            //TODO: handle exception
            i.printStackTrace();
        }
    }
}