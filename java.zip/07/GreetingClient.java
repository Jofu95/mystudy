/**
 * GreetingClient
 */
import java.io.*;
import java.net.*;
public class GreetingClient {

    public static void main(String[] args) {
        String serverName = args[0];
        int port = Integer.parseInt(args[1]);

        try {
            System.out.println("connection host: "+serverName + ", port:"+ port);
            Socket client = new Socket(serverName, port);
            System.out.println("remote host address: "+ client.getRemoteSocketAddress());

            OutputStream out = client.getOutputStream();
            DataOutputStream dout = new DataOutputStream(out);

            dout.writeUTF("hello from "+ client.getLocalSocketAddress());
            InputStream in = client.getInputStream();
            DataInputStream din = new DataInputStream(in);

            System.out.println("server response: "+ din.readUTF());
            client.close();
        } catch (IOException i) {
            //TODO: handle exception
            i.printStackTrace();
        }
    }
}