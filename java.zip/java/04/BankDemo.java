/**
 * BankDemo
 */
public class BankDemo {

    public static void main(String[] args) {
        CheckingAccount ca = new CheckingAccount(101);
        System.out.println("cun 50");
        ca.deposit(50);
        System.out.println("qu 200");
       try {
           ca.withdraw(200.0);
       } catch (InsufficientFundsException e) {
           //TODO: handle exception
           System.out.println("yu e bu gou "+ e.getAmount());
       }

    }
}