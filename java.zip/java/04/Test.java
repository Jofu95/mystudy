/**
 * Test
 */
import java.io.*;
public class Test {

    public static void main(String[] args) {
        char c = '0';
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        do {
            try {
                c = (char)br.read();
            } catch (Exception e) {
                System.out.println(e);
            }
            System.out.print(c);
        } while (c != 'q');
    }
}