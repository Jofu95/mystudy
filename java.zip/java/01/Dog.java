/**
 * Dog
 */
public class Dog {
    String breed;
    int age;
    String color;

    void braking(){

    }
    void hungry(){

    }
    void sleeping(){
        
    }
}