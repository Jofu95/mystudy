/**
 * Test6
 */
import java.util.*;
 public class Test6 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("�ȴ�����...");
        // String str = sc.next();
        // System.out.println(str);

        String str2 = sc.nextLine();
        System.out.println(str2);
    }
}