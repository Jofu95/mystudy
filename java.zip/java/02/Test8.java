/**
 * Test8
 */
public class Test8 {

    public static void main(String[] args) {
        System.out.println(new Integer(123));
        System.out.println(new Double(123));
        System.out.println(new Integer(123).doubleValue());
        System.out.println(Double.valueOf(5));
        System.out.println(Integer.parseInt("234"));
    }
}