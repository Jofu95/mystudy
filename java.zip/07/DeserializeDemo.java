/**
 * DeserializeDemo
 */
import java.io.*;
public class DeserializeDemo {

    public static void main(String[] args) {
        Employee e = null;

        try {
            FileInputStream fis = new FileInputStream("employee.ser");
            ObjectInputStream ois = new ObjectInputStream(fis);
            e = (Employee)ois.readObject();
            ois.close();
            fis.close();
        } catch (IOException i) {
            //TODO: handle exception
            i.printStackTrace();
            return;
        } catch (Exception ex){
            ex.printStackTrace();
        }

        System.out.println("Deserialized Employee...");

        System.out.println("name: "+ e.name);

        System.out.println("address: "+ e.address);

        System.out.println("ssn: "+ e.SSN);

        System.out.println("number: "+ e.number);
    }
}