//app.js
App({
  onLaunch(){
   // console.log("onLaunch");
  },

  onShow(){
    //console.log("onShow");
  },

  onHide(){
   // console.log("onHide");
  },

  onErro(err){
   // console.log("onError");
  },

  onPageNotFound(){
    console.log("onPageNotFound");
    wx.navigateTo({
      url:"/pages/demo09/demo09"
    })
  }
})