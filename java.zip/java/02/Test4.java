/**
 * Test4
 */
public class Test4 {

    public static void main(String[] args) {
        int a = 60;// 0011 1100  
        int b = 13;// 0000 1101
        int c = 0;

        c = a & b;
        System.out.println("a & b = " + c);//0000 1100 = 12
        c = a | b;
        System.out.println("a | b = " + c);//0011 1101 = 61
        c = a ^ b;
        System.out.println("a ^ b = " + c);//0011 0001 = 49
        c = ~a;
        System.out.println("~a = " + c);   //1100 0011 = -61
        c = a << 2;
        System.out.println("a << 2 = " + c);//1111 0000 = 240
        c = a >> 2;
        System.out.println("a >> 2 = " + c);//0000 1111 = 15
        c= a >>> 2;
        System.out.println("a >>> 2 = " + c);//000 1111 = 15
    }
}