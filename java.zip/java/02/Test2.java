/**
 * Test2
 */
public final class Test2 {

    final int value = 20;
    public static final int BOXWIDTH = 6;
    static final String TITLE = "Manager";

    public /*final*/ void changeValue(){
        //value = 12;
    }
}

class Test3 extends Test2{
    public void changeValue(){
    }

}