/**
 * Test7
 */
public class Test7 {

    public static void main(String[] args) {
        withdraw(12.44);
    }

    public static void withdraw(double amount) throws NullPointerException {
    }
}