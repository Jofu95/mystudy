/**
 * Test
 */
public class Test  implements Cloneable{
    String name;
    int likes;

    public static void main(String[] args) {
        Test obj = new Test();
        obj.name = "Runoob";
        obj.likes = 111;

        System.out.println(obj.name);
        System.out.println(obj.likes);
        
        try {
            Test obj2 = (Test) obj.clone();
            System.out.println(obj2.name);
            System.out.println(obj2.likes);
        } catch (Exception e) {
            //TODO: handle exception
        }
    }
    
}