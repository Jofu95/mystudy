/**
 * Test7
 */
public class Test7 {

    public static void main(String[] args) {
        String a = "��";
        switch (a) {
            case "��":
                System.out.println("a��"+ a);
                break;
        
            default:
                break;
        }
        
    }
}