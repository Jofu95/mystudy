/**
 * AutoShift
 */
public class AutoShift {

    public static void main(String[] args) {
        char ch = 'a';
        int c = ch;
        System.out.println("c:"+ c);
    }
}