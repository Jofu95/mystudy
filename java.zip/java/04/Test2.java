/**
 * Test2
 */
import java.io.*;
public class Test2 {

    public static void main(String[] args) {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String str = "";
        do {
            try {
                str = br.readLine();
            } catch (Exception e) {
                System.out.println(e);
            }
            System.out.println(str);
        } while (!str.equals("quit"));
    }
}