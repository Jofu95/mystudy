/**
 * CheckingAccount
 */
import java.io.*;
public class CheckingAccount {

    private double balance;
    public CheckingAccount(double balance){
        this.balance = balance;
        System.out.println("yu e��"+getBalance());
    }
    public void deposit(double amount){
        balance += amount;
        System.out.println("yu e��"+getBalance());
    }
    public void withdraw(double amount) throws InsufficientFundsException{
        if(amount <=balance){
            balance -= amount;
            System.out.println("yu e��"+getBalance());
        }else{
            double needs = amount - balance;
            throw new InsufficientFundsException(needs);
        }
    }

    public double getBalance(){
        return balance;
    }
}