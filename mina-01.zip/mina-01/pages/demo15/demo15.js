// pages/demo15/demo15.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list:[
      {
        id:0,
        name:"🍎",
        value:"苹果"
      },
      {
        id:1,
        name:"🍇",
        value:"葡萄"
      },
      {
        id:2,
        name:"🍌",
        value:"香蕉"
      }
    ],
    checkedList:[]
  },
  handleChange(e){
    // console.log(e)
    const checkedList = e.detail.value;
    this.setData({
      checkedList
    })
  }
})