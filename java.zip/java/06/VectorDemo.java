/**
 * VectorDemo
 */
import java.util.*;

public class VectorDemo {

    public static void main(String[] args) {
        Vector v = new Vector(3, 2);
        
        System.out.println("size:"+v.size());
        System.out.println("capacity:"+v.capacity());
        v.addElement(new Integer(1));
        v.addElement(new Integer(2));
        v.addElement(new Integer(3));
        v.addElement(new Integer(4));
        System.out.println("capacity:"+v.capacity());
        v.addElement(new Double(4.5));
        System.out.println("capacity:"+v.capacity());
        v.addElement(new Double(6.5));
        v.addElement(new Integer(7));
        System.out.println("capacity:"+v.capacity());


    }    
}