/** 
 * Test4
 */
import java.util.*;
public class Test4 {

    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("111");
        list.add("112");
        list.add("113");
        list.add("114");
        list.add("115");
        list.add(null);
        list.add(null);

        System.out.println(list);

        // list.clear();
        // System.out.println(list);
        System.out.println(list.contains("116"));
        System.out.println(list.contains("113"));

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
            if(list.get(i)=="112"){
                list.remove(i);
            }
        }

        System.out.println(list);

        
    }
}