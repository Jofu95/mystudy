/**
 * VirtualDemo
 */
public class VirtualDemo {

    public static void main(String[] args) {
        Salary s = new Salary("worker A", "beijing", 3, 3600.0);
        Employee e = new Salary("worker B", "shanghai", 2, 2400.0);

        System.out.println();
        System.out.print("Salary mailCheck --");
        s.mailCheck();
        System.out.print("Employee mailCheck --");
        e.mailCheck();
    }   
}