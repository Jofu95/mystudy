/**
 * Puppy
 */
public class Puppy {

    int puppyAge = 0;
    public Puppy(String name){
        System.out.println("С�����֣�" + name);
    }

    public void setAge(int age){
        puppyAge = age;
    }

    public int getAge(){
        return puppyAge;
    }

    public static void main(String[] args) {
        //��������
        Puppy py = new Puppy("Tom");
        System.out.println("С�����䣺"+ py.puppyAge);
        //�趨age
        py.setAge(2);
        System.out.println("С�����䣺"+ py.puppyAge);
        System.out.println(py.getAge());
    }
}