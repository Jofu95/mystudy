
class Animal {
    public String str = "name";

    Animal(){
        System.out.println("Animal constructor");
    }

    public void move() {
        System.out.println("animal can move");
    }
}

class Dog extends Animal{
    public String str = "name1";

    Dog(){
        super();
        System.out.println("Dog constrcutor");
    }

    @Override
    public void move() {
        System.out.println("dog can run and walk");
        
    }

    public void bark(){
        System.out.println(super.str);
        System.out.println("dog can bark");
        
    }
}

/**
 * TestDog
 */
public class TestDog {

    public static void main(String[] args) {
        Animal a = new Animal();
        Animal a1 = new Dog();
        a.move();
        a1.move();
        //a1.bark();
        System.out.println(a1.str);
    }
}