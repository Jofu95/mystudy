/**
 * GreetingServer
 */
import java.net.*;
import java.io.*;
public class GreetingServer extends Thread{

    private ServerSocket serverSocket;

    public GreetingServer(int port) throws IOException{
        serverSocket = new ServerSocket(port);
        serverSocket.setSoTimeout(10000);
    }

    public void run(){
        while(true){
            try {
                System.out.println("waiting remote connection, port:"+ serverSocket.getLocalPort()+"...");

                Socket s = serverSocket.accept();
                System.out.println("remote host address: "+ s.getRemoteSocketAddress());

                DataInputStream in = new DataInputStream(s.getInputStream());
                System.out.println(in.readUTF());

                DataOutputStream out = new DataOutputStream(s.getOutputStream());
                out.writeUTF("thank connection to me:"+ s.getLocalSocketAddress()+ "\nGood bye!");

                s.close();
            } catch (SocketTimeoutException st){
                System.out.println("Socket timed out");
                break;
            } catch (IOException i) {
                //TODO: handle exception
                i.printStackTrace();
                break;
            }
        }
    }

    public static void main(String[] args) {
        int port = Integer.parseInt(args[0]);

        try {
            Thread t = new GreetingServer(port);
            t.run();
        } catch (IOException e) {
            //TODO: handle exception
        }
    }
}