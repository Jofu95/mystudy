/**
 * EmployeeTest
 */
public class EmployeeTest {

    public static void main(String[] args) {
        Employee emp1 = new Employee("Runoob1");
        Employee emp2 = new Employee("Runoob2");

        emp1.empAge(26);
        emp1.empDesignation("�߼�����Ա");
        emp1.empSalary(10000);
        emp1.printEmployee();

        emp2.empAge(21);
        emp2.empDesignation("�м�����Ա");
        emp2.empSalary(8000);
        emp2.printEmployee();
    }
}