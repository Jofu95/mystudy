/**
 * PropDemo
 */
import java.util.*;
public class PropDemo {

    public static void main(String[] args) {
        Properties prop = new Properties();
        Set states;
        String str;

        prop.put("aaaa", "sadfs");
        prop.put("bbbb", "saddfss");
        prop.put("cccc", "savn");
        prop.put("dddd", "strrys");
        prop.put("eeee", "fhgg");

        states = prop.keySet();
        Iterator it = states.iterator();
        while(it.hasNext()){
            str = (String)it.next();
            System.out.println(str+" is "+ prop.getProperty(str));
        }
    }
}