/**
 * Test5
 */
import java.util.*;
public class Test5 {

    public static void main(String[] args) {
        LinkedList<Integer> list = new LinkedList<Integer>();
        list.add(123);
        list.add(null);
        list.add(null);
        System.out.println(list);
    }
   
}