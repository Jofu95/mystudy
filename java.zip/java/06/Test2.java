/**
 * Test2
 */
import java.util.*;
public class Test2 {

    public static void main(String[] args) {
        List<String> list = new ArrayList<String>();
        list.add("sdf");
        list.add("sasd");
        list.add("er3");

        //for/foreach
        for(String str : list){
            System.out.println(str);
        }
        //
        String[] strArray = new String[list.size()];
        list.toArray(strArray);
        for(String str : strArray){
            System.out.println(str);
        }
        //
        Iterator it = list.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}