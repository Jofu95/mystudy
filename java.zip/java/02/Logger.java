/**
 * Logger
 */
public class Logger {
    //˽�е�
    private String format;
    //
    public String getFormat(){
        return this.format;
    }

    public void setFormat(String format){
        this.format = format;
    }

    public static void main(String[] args){
        
    }
}