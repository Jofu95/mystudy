/**
 * Test5
 */
import java.io.*;
public class Test5 {

    public static void main(String[] args) {
        File f = new File("test2.txt");
        System.out.println(f.getName());
        System.out.println(f.getParent());
        System.out.println(f.getPath());
        System.out.println(f.isAbsolute());
        System.out.println(f.getAbsolutePath());
        System.out.println("�Ƿ�ɶ�"+f.canRead());
        System.out.println("�Ƿ��д"+f.canWrite());
        System.out.println("�Ƿ����"+f.exists());
        System.out.println("�Ƿ�ΪĿ¼"+f.isDirectory());
        System.out.println("�Ƿ�Ϊ�ļ�"+f.isFile());
        try {
            System.out.println(f.createNewFile());
        } catch (Exception e) {
            System.out.println(e);
        }
        File f2 = new File("D:/Notepad++/java");
        String[] files = f2.list();
        if(f2.isDirectory()){
            for (String s : files) {
                System.out.print(s +"��");
            }
        }
        System.out.println();
        File[] files2 = f2.listFiles();
        if(f2.isDirectory()){
            for (File s : files2) {
                System.out.print(s.getName()+",");
            }
        }
        System.out.println();
        File f3 = new File("D:/Notepad++/java/04/b.txt");
        // System.out.println(f3.mkdir());
        System.out.println(f3.mkdirs());
    }
}