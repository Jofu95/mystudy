/**
 * Test3
 */

 import java.util.*;
public class Test3 {

    public static void main(String[] args) {
        Map<String,String> map = new HashMap<String,String>();
        map.put("aaaa","1111");
        map.put("bbbb","2222");
        map.put("cccc","3333");
        map.put("dddd","4444");

        for (String key : map.keySet()) {
            System.out.println(key+"--"+map.get(key));
        }

        Iterator<Map.Entry<String,String>> it = map.entrySet().iterator();
        while(it.hasNext()){
            Map.Entry<String,String> m = it.next();
            System.out.println(m.getKey()+"--"+m.getValue());
        }

        for (Map.Entry<String,String> entry : map.entrySet()) {
            System.out.println(entry.getKey()+"--"+entry.getValue());
        }

        for (String str : map.values()) {
            System.out.println(str);
        }
    }
}