/**
 * HashTableDemo
 */

 import java.util.*;
public class HashTableDemo {

    public static void main(String[] args) {
        Hashtable ht = new Hashtable();
        Enumeration names;
        String str;
        double bal;
        
        ht.put("Zara", new Double(3434.34));
        ht.put("Mara", new Double(34.34));
        ht.put("Aara", new Double(434.34));
        ht.put("Dara", new Double(340.34));
        ht.put("Qara", new Double(343.34));

        names = ht.keys();
        while(names.hasMoreElements()){
            str = (String) names.nextElement();
            System.out.println(str+":"+ht.get(str));
        }
        
        System.out.println();
        
        bal = ((Double)ht.get("Zara")).doubleValue();
        ht.put("Zara", new Double(bal+1000));
        System.out.println("Zara:"+ht.get("Zara"));

    }
}