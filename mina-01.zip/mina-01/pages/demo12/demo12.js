// pages/demo12/demo12.js
Page({
    getPhoneNumber(e){
      console.log(e)
    },
    getUserInfo(e){
      console.log(e)
    }
})