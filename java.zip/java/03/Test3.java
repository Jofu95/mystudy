/**
 * Test3
 */
public class Test3 {

    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("abc");
        sb.append("def");
        System.out.println(sb);
        sb.reverse();
        System.out.println(sb);
        sb.delete(3,5);
        System.out.println(sb);
        System.out.println(sb.capacity());
    }
}