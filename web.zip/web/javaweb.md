软件架构
    CS结构的软件
        CS:Client/Server客户端和服务端，需要安装软件
        优点：可减轻服务器压力，将部分代码写到客户端；界面美观
        缺点：服务器更新，客户端也要更新，分布式开发较弱
    BS结构的软件
        B/S：Browser/Server浏览器和服务器，不需安装如那件，浏览器即可
        优点：服务器更新，不需要更新客户端，较强的分布式能力
        缺点：服务器压力较大；界面不如C/S结构
    
Web服务器
    硬件：一台很高配置的电脑
    软件：安装web服务器的软件
    常见web服务器：
        Tomcat:Apache组织提供的一个开源免费的web服务器，满足java EE的Servlet和jsp的规范
        WebSphere:IBM公司开发的的收费的大型Web服务器，满足了java ee 开发的所以规范
        WebLogic：BEA公司开发的一个收费的大型WEB服务器，满足了java ee 开发的所以规范
        IIS: 应用于.NET平台上
        Apache：应用于PHP平台上

Tomcat
    配置JAVA_HOME环境变量
    端口号默认8080
    查看端口号 netstat -ano
    tomcat项目发布方式：
        1)直接将项目复制到tomcat/webapps下
        2)在tomcat/conf/server.xml配置tomcat的虚拟路径
            <Context path="虚拟路径" docBase="真实路径"/>
        3)在tomcat/conf/Catalina/localhost/下配置tomcat的虚拟路径
            创建xx.xml文件配置参数，<Context docBase="真实路径"/> ，文件名为虚拟路径
    
HTTP协议：
    超文本传输协议，规定了浏览器与服务器端的数据交互的格式
    特性：
        1）基于请求-响应模型
            必须要现有请求，后有响应
            请求和响应必须成对出现
        2）简单快捷
            发送请求时，只需发送请求方式和请求路径
    请求：
        1）请求行 ：请求方式、请求路径、协议版本
            请求方式有多种，常用的有GET、POST
            GET和POST的区别：
                GET请求参数会显示在地址栏上，通常大小有限制，没有请求体
                POST请求参数不会显示在地址栏上，POST没有大小限制，有请求体
        2）请求头
            请求头的格式一般都是一个key对应一个value，也有一个key对应多个value
            Refer: 代表网页的来源
            User-Agent: 获得客户端浏览器类型
        3）请求体
            只有POST请求才有请求体
    响应：
        1）响应行：协议版本、状态码、状态码描述
            状态码： 200代表响应成功、302需要进行重定向操作、304需要查找本地缓存、404请求资源不存在、500服务器内部错误
        2）响应头
            通常都是一个key对应一个value，也有一个key对应多个value
            Location：重定向路径
            Refresh:：定时刷新
            Content-Disposition:文件下载时使用
        3）响应体

Servlet:
    运行在web服务器上的小的java程序，用于处理从web客户端发送的请求，并且对请求做出响应
    编写一个类实现servlet接口
    Servlet接口 --> GenericServlet类 通用Servelt与协议无关 --> HttpServlet类 HTTP专用

    生命周期：
        Servlet在第一次被访问时会被实例化，然后调用init()方法进行初始化(inti只会执行一次)，任何一次客户端请求都会调用service()方法，
        service跟内部请求的方式决定调用doXXX方法，当Servlet从服务器移除或服务器关闭，Servelt对象被销毁，里面的destroy()方法被调用，
        然后垃圾回收器会将其回收
    
    Servlet启动时加载: <load-on-startup>2</load-on-startup>

    Servlet中的urlPattern的配置：
        完全路径匹配：以 / 开始 ， 
        目录匹配：以 / 开始，以 /* 结束
        扩展名匹配： 不能以 / 开始，以 * 开始，如*.action 、 *.do
    
    ServletConfig对象：
        用来获取Servlet的相关配置的对象
        配置局部初始化参数：
            <init-param>
                <param-name></param-value>
                <param-value></param-value>
            </init-param>
        获取初始化参数 getInitParameter
    ServletContext对象：
        ServletContext是Servlet的上下文对象,只存在一个ServletContext对象
        配置全局初始化参数：
            <context-param>
                <param-name></param-name>
                <param-value></param-value>
            </context-param>
        获取全局初始化参数 getInitParameter
        获取请求路径的工程名 getContextPath()
        读取文件 getResourceAsStream("")     getRealPath("")
        
        域对象：指将数据存入到域对象中，数据有一定的作用范围
        存入数据：setAttribute(String name, Object obj)
        获取数据：getAttribute(String name)
        移除数据：removeAttribute(String name)

Cookie:
    分类：1）默认级别Cookie
            指的是没有设置有效时间的Cookie，关闭浏览器，就会销毁Cookie
         2）持久级别的Cookie
            指的是有有效时间的Cookie，将Cookie持久化到硬盘中，关闭浏览器不会销毁
    构造方法：
        Cookie(String name, String value)
    其他方法：
        getName()       获得Cookie名
        getValue()      获得Cookie值
        setDomain(String pattern) 设置域名
        setPath(String str) 设置有效路径
        setMaxAge(int time) 设置有效时间

Session:
    实现原理基于Cookie
    setAttribute(String name, Object value) 向session中存入数据
    getAttribute(String name) 从Session域中获取数据
    removeAttribute(String name) 从Session域中移除数据

Servlet数据访问范围：
    请求范围：ServletRequest
        创建：当用户向服务器发送一次请求，服务器创建一个Request对象
        销毁：当服务器对该次请求做出响应，服务器会销毁这个request对象
        作用范围：一次请求
    会话范围：HttpSession
        创建：服务端第一次调用getSession()方法时
        销毁：1）Session过期，默认30分钟
             2）非正常关闭服务器（正常关闭session会被序列化）
             3）手动调用session.invalidate();
        作用范围：一次会话（多次请求）
    应用范围：ServletContext
        创建：服务器启动时创建，为每个web项目创建一个单独的对象
        销毁：服务器关闭时或项目从服务器中移除
        作用范围：整个应用
    
JSP:
    jsp 等于 java代码+html
    运行原理：jsp执行时会被服务器翻译为servlet编译执行
    jsp脚本元素：
        1）<%!  %>  jsp声明 翻译成Servlet成员部分内容，声明变量、方法、内部类
        2）<%=  %>  翻译为 out.print()在servlet方法内部，用于生成html页面源码
        3）<%   %>  嵌入java代码翻译成service方法内部代码块，声明变量，内部类
    jsp注释：
        <%--  --%> 存在JSP源码中，翻译为Servlet 后注释就没有了
        <% 
            //
            /* */
            /*** */  
        %>  java代码注释，存在jsp源码中，翻译成Servlet后java代码注释也存在，生成html页面就消失
        <!-- --> html注释，存在jsp源码中，翻译为Servlet后注释存在，生成html页面注释也会存在 

    JSP指令：
        <%@ 指令名称 属性名称=属性值 属性名称=属性值 %>    
        分类：
            1）page指令，指示jsp的页面设置属性和行为
                定义jsp页面的全局属性，属性可以单独使用，也可几个或多个同时使用，jsp页面中只有import属性可多次出现
                属性：language（目前值只能为java）、extends(表明jsp编译chengServlet时继承的类，默认HttpJspBase)
                    session(表明是否可以直接使用session对象，默认为true)、buffer(表明jsp对客户端输出缓冲区大小，默认8kb)、
                    autoFlush(缓冲区大小溢出，是否自动刷新，默认true)、import(用于导入java包或类)、contentType(表明jsp被浏览器解析和打开)是采用的字符集)、
                    pageEncoding(jsp文件及jsp翻译后的Servlet保存到硬盘上采用字符集)、isError(处理jsp页面异常)、errorPage(处理jsp页面)、isELIgnored(是否忽略EL表达式)
            2）include指令，指示jsp包含那些其他页面
                <%@ include file=""%>
                在jsp页面中静态包含一个文件，同时由该jsp解析包含所有文件
                注：应该将被包含的页面结构去掉；在被包含页面定义变量，包含的页面中可以使用
            3）taglib指令，指示jsp页面包含那些标签
                <%@ taglib uri="" prefix=""%>
        
    JSP内置对象：可直接在JSP页面使用的对象
        9大内置对象：
        request         从客户端向服务器发送请求对象
        response        从服务器端向客户端做出响应对象
        session         服务器为客户端创建会话对象
        application     代表应用，获得的ServletContext对象
        out             像输入流写入内容对象
        page            当前JSP翻译成Servlet后的对象的引用
        pageContext     当前JSP页面的上下文对象
        config          当前JSP的ServletConfig对象
        exception       JSP页面运行时产生的异常对象
    
    内置对象具体类型：
        request         HttpServletRequest
        response        HttpServletResponse
        session         HttpSession
        application     ServletContext
        out             JspWriter
        page            Object
        pageContext     PageContext
        config          ServletConfig
        exception       Throwable

    pageContext对象作用：
        通过该对象可获得其他8个内置对象 getXxx()
        setAttribute(String name, Object obj)
        getAttribute(String name)
        removeAttribute(String name)
        findAttribute(String name)
    
    4个作用范围：
        PageScope           页面范围，在当前页面内有效，超出范围保存在pageContext的数据无效
        RequestScope        请求范围，客户端向服务器端发送一次请求，服务器对该请求做出响应后，保存在request中的数据无效
        SessionScope        会话范围，每个浏览器向服务器发送请求(多次请求)，将该会话结束
        ApplicationScope    应用范围，整个应用中任意地方都可以获取

    动作标签：
        用于在JSP页面中提供业务逻辑功能，避免直接在jsp页面中写java代码，造成页面难以维护
        常用动作标签：
            <jsp:forword /> 请求转发
            <jsp:include /> 包含（动态包含）
            <jsp:param />   传递参数
        
    EL表达式：
        功能：获取数据；执行运算；获取web开发常用对象
        语法：${ el表达式 }     无值为空字符串不为null
        常用对象：
            param           页面中接收请求参数(一个名称对应一个参数)
            paramValues     
        
    JSTL：jsp标准标签库
        c标签（core标签库）
        fmt标签(国际化标签)
        xml标签
        sql标签
        jstl函数库(el函数)

        <c:if></c:if>
            test属性：条件
            var属性：将test中的条件的值赋给变量，在var中定义变量
            scope属性：作用范围
        <c:forEach></c:forEach>

监听器：
    实现了特定接口的java类，用于监听另一个java类的方法调用或属性改变，当被监听对象发生改变后，监听器某个方法将会立即执行
    事件源：被监听对象
    监听器：监听对象
    事件源和监听器绑定：监听器监听被监听对象
    事件：事件源对象的改变
    Servlet中定义了多种类型的监听器，用于监听的事件源分别是ServletContext、HttpSession、ServletRequest三个域对象
    
过滤器：

文件上传：将本地文件通过流写入到服务器的过程
    文件上传技术：
        1）JSPSmartUpload 应在JSP上的文件上传和下载的组件
        2）FileUpload 应用在Java环境上的文件上传的功能
        3）Servlet 3.0
        4）、Struts2
    文件上传要素：
        1）表单提交方式为post
        2）表单中需要有<input type="file"/>，需要name属性
        3）表单属性 enctype="multipart/form-data"
    
    DiskFileItemFactory磁盘文件工厂
        DiskFileItemFactory()
        DiskFileItemFactory(int sizeThreshold, File repository)
            sizeThreshold  设置文件上传的缓冲区大小，默认值为10kb
            repository  设置文件上传过程中产生的临时文件存放路径
        setRepository(File repository)          设置临时文件存放路径
        setSizeThreshold(int sizeThreshold)     设置缓冲区大小

    ServletFileUpload核心解析类
        ServletFileUpload(FileItemFactory fileItemfactory)
        方法：
         boolean isMultipartContent(HttpServletRequest request)  判断表单是否是enctype属性
         List parseRequest(HttpServletRequest request) 解析Request对象，返回List集合
         setFileSizeMax(long fileSizeMax)   设置单个文件大小
         setSizeMax(long sizeMax)   设置上传文件的总的大小
         setHeaderEncoding(String encoding)    设置中文文件名上传乱码问题
         setProgressListener(ProgressListener pListener)    设置监听文件上传进度

    FileItem文件项
        boolean isFormFile()    判断表单是普通项还是文件上传项，true代表普通项
        String getFieldName()   获得普通项名称
        String getString()      获得普通项的值
        String getName()       或的文件上传的名称
        InputStream getInputStream()    获得文件上传输入流
        long getSize()          获得文件上传文件的大小
        delete()                删除临时文件

文件下载：
    方式一：超链接方式
    方式二：手动编码
        response.setContentType(type);
        response.setHeader("Content-Disposition", "attachment;filename="+filename); 

Maven:
    常规项目开发存在问题：
    1）一个项目就是一个web工程，如果项目庞大，利用包名package来划分模块，容易造成混淆不利于分工合作
    2）项目中需要jar包必须手动复制到WEB-INF/lib目录下。会导致每创建一个项目就要重复复制粘贴
    3）jar包需要手动去官网或其他地方下载
    4）一个jar包依赖其他jar包，需要手动添加项目中，可能导致遗漏而使项目出错

    目标：提供给开发人员
    1）项目可重复使用，易维护，更容易理解的综合模型
    2）插件或交互工具，声明性模式
    Maven项目的结构和内容是在一个XML文件中声明，pom.xml的项目对象模型，是整个maven系统的基本单元

    Maven的理念：约定大于配置

    配置环境变量：MAVEN_HOME="maven的安装目录" ，path中添加 %MAVEN_HOME%/bin
    查看环境变量是否配置成功，dos窗口输入mvn -v
    
    Group Id和Artifact Id被统称为坐标，为保证项目的唯一性
    Group Id 一般分为多个段，第一段为域，第二段为公司名称。域分为org、com、cn等等许多，org为非营利组织，com为商业组织
    Artifact Id 是项目的为一标识符，实际对应项目的名称，就是项目的根目录的名称

    遵循 约定 >>> 配置 >>> 编码，即能进行配置的不要去编码指定，能实现约定的规则就不要去进行配置
    pom.xml(项目对象模型)，maven的核心配置文件，与构建过程相关的一切配置都在这个文件中进行
    
    maven常用指令：
      mvn compile 编译，将java源程序编译成class字节码文件
      mvn test 测试，并生成测试报告
      mvn clean 将以前编译得到的旧的class字节码文件删除
      mvn package 打包，动态web工程打war包，java工程打jar包
      mvn install 将项目生成jar包放在仓库，以便别的模块调用

    依赖：
      导入的jar包与其他jar包之间的相关联，那么它们存在依赖关系
      maven在pom.xml文件进行相应的配置，自动管理jar包之间的依赖关系
    依赖配置：
      <dependencies> 一个pom文件中只能存在一个该标签，管理以来的总标签
      <denpendcy> 包含在denpendencies标签中，可以有无数个，每一个表示一个依赖
      <groupid>、<artifactId>、<version> 依赖的基本坐标，对于任何一个依赖，基本坐标最重要，maven根据坐标才能找到依赖
      <type> 依赖的类型，对应于项目坐标定义的packaging，大部分情况不必声明，默认为jar
      <scope> 依赖的范围，默认值为compile 
      <exclusions> 用来排除传递性依赖
    依赖范围<scope>：
      1.compile范围依赖
        对主程序有效、对测试程序有效、参与打包、参与部署；例如log4j
      2.test范围依赖
        对主程序无效、对测试程序有效、不参与打包、不参与部署；例如Junit
      3.provivded范围依赖
        对主程序有效、对测试程序有效、不参与打包、不参与部署；例如servlet-api.jar
      4.runtime范围依赖
        例如jdbc
    依赖传递：最先依赖的为第一直接依赖
      第二依赖的范围是compile时，传递性依赖范围与第一依赖范围一致
      第二依赖的范围是test时，依赖不会传递
      第二依赖的范围是provivded时，第一依赖范围为provivded的才进行传递
      第二依赖的范围是runtime时，传递性依赖范围与第一依赖范围一致，除compile例外为runtime
    依赖排除：
      在依赖下添加<exclusions>排除依赖
    依赖冲突：
      1.跨pom文件冲突
        依赖关系中，第一直接依赖版本与直接依赖的项目版本相同
      2.同一pom文件冲突 
        先声明者优先，依赖的版本会被后之后声明的版本覆盖
    可选依赖：
      <option> 默认为false，为true表示依赖不会传递

    声明周期：
      1.Clean Lifecycle 进行真正的构建之前进行一些清理工作
        pre-clean 执行一些需要在clean之前完成的工作
        clean 移除所有上一次构建生成的文件
        post-clean 执行一些需要在clean之后立刻完成的工作
        mvn -clean 相当于 pre-clean clean
      2.Default Lifecycle 构建的核心部分，编译、测试、打包、安装、部署等等
      3.Site Lifecycle 生成项目报告，站点，发布站点
    
    插件：
      配置编译插件
      <build> -> <plugins> -> <plugin> -> <configuration>
    
    继承：
      如何管理不同工程对于某个jar包的版本？
        将jar包版本统一提到父工程，在子工程声明依赖不指定版本，以父工程统一设定为准
    聚合：
      一个项目多个maven工程，每个都需要打包？
      创建聚合工程，将其他各个模块都有聚合工程管理，只需打包聚合工程
      创建Maven Project工程，打包为pom
      创建Maven Moodule子工程，除web层位war，其余都为jar
      在聚合工程添加子工程的引用<modules> -> <module>
      

单点登录：
  一、单系统登陆机制
    1.http无状态协议
       http是无状态协议，浏览器每次请求，服务器都会独立处理，不与之前或之后的请求产生关联
    2.会话机制
       浏览器第一次请求服务器，服务器创建一个会话，并将会话的id作为响应的一部分发送给浏览器，浏览器存储id，
       当第二次/第三次请求中带上会话id，服务器取得请求中的会话id，判断是不是同一用户
    3.登陆状态
       第一次登陆成功后，将用户登陆状态记录保存在会话对象中，下一次请求，会对会话对象中用户状态进行查看，只有在登陆状态才允许访问
  二、多系统的复杂性
    访问web系统的整个应用群与访问单个系统是一样，登录/注销只有一次
    单系统的登录解决方案核心是cookie，cookie携带会话id在浏览器和服务器之间维护会话状态，但cookie是有限制的(cookie的域)，
    浏览器发送请求时会自动携带与该域匹配的cookie，而不是所有的cookie
  三、单点登录
    单点登录简称SSO(Single Sign On),是指在多系统应用群中登录一个系统，便可在其他所有系统中得到授权而无需再次登录，包括单点登录和单点注销
    1.登录
      相当于单系统登陆，sso需要一个认证中心，只有认证中心能够接收用户名和密码等安全信息，其它系统不同供登录入口，只接受认证中心的间接授权，
      间接授权通过令牌实现，sso认证中心验证用户无问题后，创建授权令牌，在接下来跳转过程中，授权令牌作为参数发送给各个子系统，子系统拿到令牌，
      即得到授权，可以借此创建局部会话，局部会话登陆方式与单系统登陆方式相同，这个过程为单点登录原理
      1）用户访问系统A的受保护资源，系统A发现用户未登录，跳转至sso认证中心，并将自己的地址作为参数
      2）sso认证中心发现用户未登录，将用户引导至登陆页面
      3）用户输入用户名和密码提交登陆申请
      4）sso认证中心校验用户信息，创建用户与sso认证中心之间的会话，称为全局会话，同时创建令牌
      5）sso认证中心带着令牌跳转到最初的请求地址（系统A）
      6）系统A拿到令牌，去认证中心校验令牌是否有效
      7）sso认证中心校验令牌，返回有效，注册系统A
      8）系统A使用该令牌创建与用户的会话，称为局部会话，返回受保护资源
      9）用户访问系统B的受保护资源
      10）系统B发现未登录，跳转到sso认证中心，并将自己的地址作为参数
      11）sso认证中心发现用户已登录，跳转回系统B，并附上令牌
      12）系统B拿到令牌，去sso认证中心校验令牌是否有效
      13）sso认证中心校验令牌，返回有效，注册系统B
      14）系统B使用该令牌创建与用户的会话，返回受保护资源
      登录成功后，会与sso认证中心及各个子系统建立会话，用户与sso认证中心建立的会话称为全局会话，用户与各个子系统建立的会话称为局部会话，
      局部会话建立后，用户不需要通过sso认证中心访问子系统的受保护资源。全局会话与局部会话有如下约束：
        ·局部会话存在，全局会话一定存在
        ·全局会话存在，局部会话不一定存在
        ·全局会话销毁，局部会话必须销毁
    2.注销
      sso认证中心一直监听全局会话状态，一旦全局会话销毁，监听器将会通知所有注册的系统执行销毁操作
      1）用户向系统A发起注销请求
      2）系统A通过用户与系统A建立的会话id拿到令牌，向sso认证中心发起注销请求
      3）sso认证中心校验令牌有效，销毁全局会话，同时取出所有用此令牌的系统地址
      4）sso认证中心向所有登录系统发起注销请求
      5）各系统接收sso认证中心的注销请求，销毁局部会话
      6）sso认证中心引导用户到登陆页面
  四、实现
    
      

