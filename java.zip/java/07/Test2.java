/**
 * Test2
 */
import java.util.*;
public class Test2 {

    private List synchedList;

    public Test2(){
        synchedList = Collections.synchronizedList(new LinkedList());
    }

    public String removeElement() throws InterruptedException{
        synchronized (synchedList){
            while(synchedList.isEmpty()){
                System.out.println("list is Empty...");
                synchedList.wait();
                System.out.println("Waiting...");
            }
            String element = (String) synchedList.remove(0);
            return element;
        }
    }

    public void addElement(String element){
        System.out.println("opening...");

        synchronized(synchedList){
            synchedList.add(element);
            System.out.println("new Element :"+ element);
        }

        System.out.println("closing");
    }

    public static void main(String[] args) {
        final Test2 t = new Test2();
        
        Runnable runA = new Runnable(){
            public void run(){
                try {
                    String item = t.removeElement();
                    System.out.println(""+item);
                }catch(InterruptedException ie){
                    System.out.println("InterruptedException");
                }catch (Exception e) {
                    System.out.println("Exception");
                }
            }
        };

        Runnable runB = new Runnable(){
            public void run(){
                t.addElement("hello");
            }
        };

        try {
            Thread th1 = new Thread(runA, "Google");
            th1.start();
            Thread.sleep(500);

            Thread th2 = new Thread(runA, "Runoob");
            th2.start();
            Thread.sleep(500);

            Thread th3 = new Thread(runB, "Taobao");
            th3.start();
            Thread.sleep(1000);

            th1.interrupt();
            th2.interrupt();
        } catch(InterruptedException ie){
            System.out.println("InterruptedException");
        }
    }
}