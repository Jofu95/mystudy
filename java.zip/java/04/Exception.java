/**
 * Exception
 */
public class Exception {

    public static void main(String[] args) {
        int[] a = new int[2];
        try {
            System.out.println(a[3]);
            
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e);
            System.exit(0);
        }finally{
            System.out.println("����");
        }
    }
}