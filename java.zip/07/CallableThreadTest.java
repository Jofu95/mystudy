/**
 * CallableThreadTest
 */
public class CallableThreadTest implements Callable<Integer>{

    public static void main(String[] args) {
        CallableThreadTest ctt = new CallableThreadTest();
        FutureTask<Integer> ft = new FutureTask<Integer>(ctt);

        for (int i = 0; i < 100; i++) {
            System.out.println(Thread.currentThread().getName()+"  "+ i);
            if(i == 20){
                new Thread(ft, "ft ").start();
            }
        }

        try {
            System.out.println("zi :"+ft.get());
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            //TODO: handle exception
            e.printStackTrace();
        }
    }

    @Override
    public Integer call() throws Exception{
        int i = 0;
        for (; i < 100; i++) {
            System.out.println(Thread.currentThread().getName()+" "+ i);
        }
        return i;
    }
}