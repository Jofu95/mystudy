/**
 * Test
 */
public class Test {

    public void pupAge(){
        int age = 0;
        //int age; //�ֲ�������δ��ʼ��
        age = age + 7;
        System.out.println("Puppy age is :" + age);
    }

    public static void main(String[] args) {
        Test t = new Test();
        t.pupAge();
    }
}