/**
 * Test3
 */
import java.io.*;
public class Test3 {

    public static void main(String[] args) {
        byte[] b = {11, 21, 3, 40, 5};
        OutputStream out = null;
        try {
            out = new FileOutputStream("test.txt");
            for (int i = 0; i < b.length; i++) {
                out.write(b[i]);
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        InputStream in = null;
        try {
            in = new FileInputStream("test.txt");
            int size = in.available() ;
            for (int i = 0; i < size; i++) {
                System.out.println((byte)in.read());
            }
        } catch (Exception e) {
            System.out.println(e);
        }

        try {
            if(out !=null){
                out.close();
            }
            if(in !=null){
                in.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}