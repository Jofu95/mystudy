Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg:"hello mina",
    num:1,
    isGirl:false,
    Person:{
      name:"张三",
      age:24
    },
    isChecked:true,
    list:[
      {
        id:0,
        name:"猪八戒"
      },
      {
        id:1,
        name:"天蓬元帅"
      },
      {
        id:2,
        name:"悟能"
      }
    ]
  }
})