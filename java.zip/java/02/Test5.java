/**
 * Test5
 */
public class Test5 {

    public static void main(String[] args) {
        int num = 0;
        while(num < 3){
            System.out.println("*******");
            num++;
        }
        System.out.println();
        num = 0;
        do {
            System.out.println("*******");
            num++; 
        } while (num < 3);
        System.out.println();
        for(int i=0;i < 3; i++){
            System.out.println("*******");
        }

        int[] nums = {1,3,5,7};
        for(int i : nums){
            System.out.println(i);
        }
    }
}