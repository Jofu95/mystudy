java servlet是运行在web服务器或应用服务器上的程序

servlet任务：
    1.读取客户端（浏览器）发送的显示的数据。
    2.读取客户端（浏览器）发送的隐式的HTTP请求数据
    3.处理数据并产生结果
    4.发送显示的数据（即文档）到客户端（浏览器）
    5.发送隐式的HTTP响应到客户端（浏览器）

servlet生命周期：
    1.Servlet初始化后调用init()方法
    2.Servlet调用service()方法处理客户端请求
    3.servlet销毁前调用destroy()方法

    init()方法只调用一次
    service()方法是Servlet处理来自客户端(浏览器)的请求时调用的方法
    每次服务器接收到servlet请求，服务器会创建一个新的线程并调用service()方法

使用servlet读取表单数据：
    getParameter()  request.getParameter()方法获取表单参数值
    getParameterValues()   request.getParameterValues()
    getParameterNames()    request.getParameterNames()

过滤器：
    可以动态的拦截请求和响应，以变换或使用包含在请求或响应中的信息
    实现以下目的：
        1.在客户端的请求访问后端资源之前，拦截请求
        2.在服务器的响应发送回给客户端之前，处理响应
    
    各类型过滤器：
        身份验证过滤器、数据压缩过滤器、加密过滤器、触发资源访问事件过滤器、图像转换过滤器、日志记录和审核过滤器、
        MIME-TYPE链过滤器、标记化过滤器、XSL/T过滤器（转换XML内容）
    实现Filter接口，实现三个方法doFilter、init、destroy
    init()方法提供了FilterConfig对象，可通过该对象获取web.xml中初始化参数

Cookie:
    存储在计算机上的文本文件，并保留了各种跟踪信息
    cookie处理需要对中文进行编码和解码：
        URLEncoder.encode("中文", "utf-8");
        URLDencoder.decode("编码后的字符串", "utf-8");
    cookie通常设置在HTTP头信息中
    setMaxAge(int expiry)   设置cookie过期时间(秒为单位)
    String getName()        返回cookie名称
    String getValue()       返回cookie值


