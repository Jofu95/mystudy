/**
 * Test7
 */
import java.util.Date;
import java.text.*;
public class Test7 {

    public static void main(String[] args) {
        Date date =new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss E");
        SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss E");
        System.out.println(sdf.format(date));
        System.out.println(sdf2.format(date));
        try {
            System.out.println(sdf.parse("2020/10/22 22:22:22").toString());
        } catch (Exception e) {
            //TODO: handle exception
            System.out.println(e);
        }
    }
}