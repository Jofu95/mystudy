/**
 * Test6
 */
import java.util.Date;
public class Test6 {

    public static void main(String[] args) {
        Date date = new Date();
        System.out.println(date);
        Date date2 = new Date(2342424);
        System.out.println(date2);
        System.out.println(new Date().after(date));
        System.out.println(date.before(new Date()));
        System.out.println(date.toString());
    }
}