/**
 * InstanceCounter
 */
public class InstanceCounter {

    private static int num = 0;
    protected static int getCount(){
        return num;
    }

    private static void addNum(){
        num++;
    }

    InstanceCounter(){
        InstanceCounter.addNum();
    }

    public static void main(String[] args) {
        System.out.println("Starting with "+ InstanceCounter.getCount());
        for (int i = 0; i < 500; i++) {
            new InstanceCounter();
        }

        System.out.println("Created " + InstanceCounter.getCount());
    }
}