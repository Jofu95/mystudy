/**
 * Test1
 */
public class Test1 {

    public static void main(String[] args) {
        String str = "hello";
        System.out.println(str.replace('o','1'));
        System.out.println(str.replaceAll("ello", ""));
        for (String s : str.split("")) {
            System.out.println(s);
        }
        System.out.println(str.startsWith("h"));
        System.out.println(str.substring(2));
        //System.out.println(str.substring(-2));
        System.out.println(str.substring(2,4));                                 
        for (char ch : str.toCharArray()) {
            System.out.println(ch);
        }
    }
}