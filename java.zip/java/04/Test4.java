/**
 * Test4
 */
import java.io.*;
public class Test4 {

    public static void main(String[] args) {
        try {
            File f = new File("a.txt");
            OutputStream os = new FileOutputStream(f);
            OutputStreamWriter writer = new OutputStreamWriter(os, "UTF-8");
            writer.append("��������");
            writer.append("\r\n");
            writer.append("English");
            writer.close();

            InputStream is = new FileInputStream(f);
            InputStreamReader reader = new InputStreamReader(is,"Utf-8");
            StringBuffer sb = new StringBuffer();
            while (reader.ready()) {
                sb.append((char)reader.read());
            }
            System.out.println(sb.toString());
            reader.close();
            is.close();
        os.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}