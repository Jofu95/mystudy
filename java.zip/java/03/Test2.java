/**
 * Test2
 */
public class Test2 {

    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("test");
        System.out.println(sb);
        sb.append("stringbuffer");
        System.out.println(sb);
    }
}