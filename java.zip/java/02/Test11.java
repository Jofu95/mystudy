/**
 * Test11
 */
public class Test11 {

    public static void main(String[] args) {
        String str1 = "hello";
        String str2 = "world";
        System.out.println("charAt:"+ str1.charAt(4));
        System.out.println("compareTo:" + str1.compareTo(str2));
        System.out.println("concat:"+ str1.concat(str2));
        System.out.println("endsWith:"+str1.endsWith("lo"));
        System.out.println("equals:"+str1.equals(str2));
        try {
            System.out.println("getBytes:"+str1.getBytes());
            System.out.println("getBytes:"+str1.getBytes("UTF-8"));
        } catch (Exception e) {
        }
        System.out.println("hashCode:"+str1.hashCode());
        System.out.println("indexOf:"+str1.indexOf("ll"));
        System.out.println("lastIndexOf:"+str1.lastIndexOf('l'));
        System.out.println("length:"+ str1.length());
        System.out.println("replace:"+ str1.replace('l', 'a'));
    }
}