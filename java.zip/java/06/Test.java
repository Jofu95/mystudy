/**
 * Test
 */
import java.util.*;
public class Test {

    public static void main(String[] args) {
        ArrayList<String> sites = new ArrayList<String>();
        sites.add("Google");
        sites.add("Runoob");
        sites.add("Taobao");
        sites.add("Zhihu");

        //het Iterator
        Iterator it = sites.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}